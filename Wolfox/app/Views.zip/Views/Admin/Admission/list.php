 
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                  
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Student List</h4>
                                 <div class="table-responsive">
                                    <table class="table">
                                        <thead class="bg-success text-white" style="background-color: #2962ff !important;">
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>Action</th>
                                                <th>Full Name</th>
                                                <th>Email</th>
                                                <th>Mob No.</th>
                                                <th>  Whatsapp No. </th>
                                                 <th>Gender</th>
                                                <th>DOB</th>
                                                <th>Address</th>
                                                <th>College Name</th>
                                                <th>Branch</th>
                                                <th>Year</th>
                                                <th>Course </th>
                                                <th>Duration</th>
                                                <th>Batch Time</th>
                                                <th>Joining Date</th>






                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($StudentData as $row):
                                            ?>
                                            <tr>
                                                <td><?php echo $row['id'] ?></td>
                                                <td><a href="<?php echo base_url('/Admin/Admission/Edit/'.$row['id'].'')?>"><div style="width: 60px; border:1px solid #2962ff;text-align:center;border-radius:5px;background-color:#2962ff;color:white">Edit</div></a></td>
                                                <td><?php echo $row['firstname'] ?> <?php echo $row['middlename'] ?> <?php echo $row['lastname'] ?></td>
                                                <td><?php echo $row['email'] ?></td>
                                                <td><?php echo $row['phoneno'] ?></td> 
                                                <td> <?php echo $row['whatsappno'] ?></td>
                                                <td><?php echo $row['gender'] ?></td>
                                                <td><?php echo $row['dob'] ?></td>
                                                <td><?php echo $row['pstreet'] ?>,<?php echo $row['pcity'] ?>,<?php echo $row['pstate'] ?>-<?php echo $row['ppincode'] ?></td>
                                                <td><?php echo $row['college'] ?></td>
                                                <td><?php echo $row['branch'] ?></td>
                                                <td><?php echo $row['year'] ?></td>
                                                <td><?php echo $row['course'] ?></td>
                                                <td><?php echo $row['duration'] ?></td>
                                                <td><?php echo $row['batchtime'] ?></td>
                                                <td><?php echo $row['joiningdate'] ?></td>

                                            </tr>
                                            <?php 
                                            endforeach;
                                            ?>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 
                <!-- row -->
                
                <!-- row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            