 
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                  
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Course List</h4>
                                 <div class="table-responsive">
                                    <table class="table">
                                        <thead class="bg-success text-white" style="background-color: #2962ff !important;">
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>Action</th>
                                                 
                                                <th>Course Name</th>
                                                <th>Duration</th>
                                                <th>Fee</th>
                                                <th>Languages</th>

                                                 






                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($CourseData as $row):
                                            ?>
                                            <tr>
                                                <td><?php echo $row['id'] ?></td>
                                                <td><a href="<?php echo base_url('/Admin/Course/Edit/'.$row['id'].'')?>"><div style="width: 60px; border:1px solid #2962ff;text-align:center;border-radius:5px;background-color: #2962ff !important;;color:white">Edit</div></a></td>
                                                 
                                                <td><?php echo $row['course'] ?></td> 
                                                <td> <?php echo $row['duration'] ?></td>
                                                <td> <?php echo $row['fee'] ?></td>
                                                <td> <?php echo $row['languages'] ?></td>

                                                 

                                            </tr>
                                            <?php 
                                            endforeach;
                                            ?>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 
                <!-- row -->
                
                <!-- row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            