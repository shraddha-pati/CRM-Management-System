<div class="page-wrapper">

    <div class="container-fluid">

        <div class="row">

            <div class="col-12">
                <div class="card">
                    <div class="card-body wizard-content">
                        <h4 class="card-title">Student Admission</h4>
                        <h6 class="card-subtitle"></h6>
                        <form action="<?php echo base_url('/Admin/Admission/Update') ?>" class="tab-wizard wizard-circle" method="post">

                            <h6>Personal Info</h6>
                            <section>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="firstName1">id</label>
                                            <input type="text" class="form-control" id="id" name="id" value="<?php echo $StudentData['id'] ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="firstName1">First Name</label>
                                            <input type="text" class="form-control" id="FirstName" name="FirstName" value="<?php echo $StudentData['firstname'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="firstName1">Middle Name </label>
                                            <input type="text" class="form-control" id="MiddleName" name="MiddleName" value="<?php echo $StudentData['middlename'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="lastName1">Last Name </label>
                                            <input type="text" class="form-control" id="LastName" name="LastName" value="<?php echo $StudentData['lastname'] ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="emailAddress1">Email Address</label>
                                            <input type="email" class="form-control" id="Email" name="Email" value="<?php echo $StudentData['email'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="phoneNumber1">Phone Number</label>
                                            <input type="tel" class="form-control" id="PhoneNo" name="PhoneNo" value="<?php echo $StudentData['phoneno'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="phoneNumber1">Whatsapp Number </label>
                                            <input type="tel" class="form-control" id="WhatsappNo" name="WhatsappNo" value="<?php echo $StudentData['whatsappno'] ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1">Select Gender</label>
                                            <select class="custom-select form-control" id="Gender" name="Gender" value="<?php echo $StudentData['gender'] ?>">
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="date1">Date of Birth</label>
                                            <input type="date" class="form-control" id="DOB" name="DOB" value="<?php echo $StudentData['dob'] ?>">
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <!-- Step 2 -->
                            <h6>Address Information</h6>
                            <section>
                                <h5>Current Address</h5>
                                <br>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">Street </label>
                                            <input type="text" class="form-control" id="CStreet" name="CStreet" value="<?php echo $StudentData['cstreet'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">City </label>
                                            <input type="text" class="form-control" id="CCity" name="CCity" value="<?php echo $StudentData['ccity'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">State </label>
                                            <input type="text" class="form-control" id="CState" name="CState" value="<?php echo $StudentData['cstate'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">Pincode </label>
                                            <input type="text" class="form-control" id="CPincode" name="CPincode" value="<?php echo $StudentData['cpincode'] ?>">
                                        </div>
                                    </div>
                                </div>
                                <h5>Permanent Address</h5>
                                <button type="button" id="btn" style="border:none;background-color:#2962ff;color:white;border-radius:5px"> Same as Current</button>
                                <br>
                                <br>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">Street </label>
                                            <input type="text" class="form-control" id="PStreet" name="PStreet" value="<?php echo $StudentData['pstreet'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">City </label>
                                            <input type="text" class="form-control" id="PCity" name="PCity" value="<?php echo $StudentData['pcity'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">State </label>
                                            <input type="text" class="form-control" id="PState" name="PState" value="<?php echo $StudentData['pstate'] ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="jobTitle1">Pincode </label>
                                            <input type="text" class="form-control" id="PPincode" name="PPincode" value="<?php echo $StudentData['ppincode'] ?>">
                                        </div>
                                    </div>
                                </div>
                            </section>



                            <!-- Step 3 -->
                            <h6>Educational Information</h6>
                            <section>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="int1">College Name</label>
                                        <input type="text" class="form-control" id="College" name="College" value="<?php echo $StudentData['college'] ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="int1">Branch</label>
                                        <input type="text" class="form-control" id="Branch" name="Branch" value="<?php echo $StudentData['branch'] ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="int1">Year</label>
                                        <select name="Year" id="Year" class="form-control" value="<?php echo $StudentData['year'] ?>">
                                            <option value="FirstYear">First Year</option>
                                            <option value="SecondYear">Second Year</option>
                                            <option value="ThirdYear">Third Year</option>
                                            <option value="FourthYear">Fourth Year</option>
                                            <option value="Passout">Passout</option>

                                        </select>
                                    </div>

                                </div>
                            </section>
                            <!-- Step 4 -->
                            <h6>Course Details</h6>
                            <section>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="Course">Select Course</label>
                                        <select name="Course" id="Course" class="form-control" value="<?php echo $StudentData['course'] ?>">
                                            <?php
                                            foreach ($CourseData as $row):
                                            ?>
                                            <?php

                                                echo '<option value="' . $row['courseid'] . '">' . $row['course'] . '</option>';


                                            endforeach; ?>
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="BatchTime">Batch Time</label>
                                        <select name="BatchTime" id="BatchTime" class="form-control">
                                            <option value="">Select Batch Time</option>
                                            <?php foreach ($BatchData as $row) : ?>
                                                <option value="<?= $row['batchid'] ?>">
                                                    <?= date("h:i A", strtotime($row['starttime'])) . ' - ' . date("h:i A", strtotime($row['endtime'])) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="BatchTime">Date of Joining</label>
                                        <input type="date" id="JoiningDate" name="JoiningDate" class="form-control" value="<?php echo $StudentData['joiningdate'] ?>">

                                    </div>


                                </div>
                                <button type="submit" style="float: right;margin-top:80px"> Submit</button>

                            </section>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("btn").addEventListener("click", function(event) {
                event.preventDefault(); // Just in case the form is still trying to submit

                // Copy values from current address to permanent address
                document.getElementById("PStreet").value = document.getElementById("CStreet").value;
                document.getElementById("PCity").value = document.getElementById("CCity").value;
                document.getElementById("PState").value = document.getElementById("CState").value;
                document.getElementById("PPincode").value = document.getElementById("CPincode").value;
            });
        });
    </script>