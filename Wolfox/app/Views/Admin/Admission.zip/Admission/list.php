<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
.icon-link {
    display: inline-block;
    margin: 5px;
    text-align: center;
    margin: 20px;
}

.icon-link i {
    font-size: 26px;
    color: black;
    transition: color 0.3s ease;
}

.icon-link i:hover {
    color: #1e4db7;
}
</style>
 <div class="page-wrapper">
     
     <div class="container-fluid">
                  <div class="row">

             <div class="col-lg-12">
                 <div class="card">
                     <div class="card-body">
                         <h4 class="card-title">Student List</h4>
                         <div class="table-responsive">
                             <table class="table">
                                 <thead class="bg-success text-white" style="background-color: #2962ff !important;">
                                     <tr>
                                         <th>Sr.no</th>
                                         <th>StudentID</th>
                                         <th>Action</th>
                                         <th>Full Name</th>
                                         <th>Email</th>
                                         <th>Mob No.</th>
                                         <th> Whatsapp No. </th>
                                         <th>Gender</th>
                                         <th>DOB</th>
                                         <th>Address</th>
                                         <th>College Name</th>
                                         <th>Branch</th>
                                         <th>Year</th>
                                         <th>Course </th>
                                         <th>Batch Time</th>
                                         <th>Joining Date</th>
                                     </tr>
                                 </thead>
                                 <tbody>
                                     <?php foreach ($StudentData as $row):
                                        ?>
                                         <tr>
                                             <td><?php echo $row['id'] ?></td>
                                             <td><?php echo $row['StudentId'] ?></td>

                                             <td>
                                                 <a href="<?php echo base_url('/Admin/Admission/Edit/' . $row['id'] . '') ?>">
                                                     <div style="width: 60px; border:1px solid #2962ff;text-align:center;border-radius:5px;background-color:#2962ff;color:white">Edit</div>
                                                 </a><br>
                                                 <a href="#" class="openModalBtn"
                                                     data-bs-toggle="modal"
                                                     data-bs-target="#exampleModal"
                                                     data-id="<?= $row['id']; ?>"
                                                     data-id="<?= $row['firstname']; ?>">
                                                     <div style="width:90px;text-align:center;border:1px solid green;background-color:green;color:white;border-radius:10px">
                                                         Fee Status
                                                     </div>
                                                 </a>
                                                 <br>
                                                 <a href="<?php echo base_url('/Admin/Admission/Edit/' . $row['id'] . '') ?>">
                                                    <i class="fa-solid fa-file"style="font-size:22px; " class="icon-link"></i>
                                                 </a>
                                                 <a href="<?php echo base_url('/Admin/Admission/Edit/' . $row['id'] . '') ?>">
                                                    <i class="fa-solid fa-scroll"style="font-size:22px; "class="icon-link" ></i>
                                                 </a>

                                             </td>
                                             <td><?php echo $row['firstname'] ?> <?php echo $row['middlename'] ?> <?php echo $row['lastname'] ?></td>
                                             <td><?php echo $row['email'] ?></td>
                                             <td><?php echo $row['phoneno'] ?></td>
                                             <td> <?php echo $row['whatsappno'] ?></td>
                                             <td><?php echo $row['gender'] ?></td>
                                             <td><?php echo $row['dob'] ?></td>
                                             <td><?php echo $row['pstreet'] ?>,<?php echo $row['pcity'] ?>,
                                                 <?php echo $row['pstate'] ?>-<?php echo $row['ppincode'] ?></td>
                                             <td><?php echo $row['college'] ?></td>
                                             <td><?php echo $row['branch'] ?></td>
                                             <td><?php echo $row['year'] ?></td>
                                             <td><?php echo $row['course'] ?></td>
                                             <td><?php echo date("h:i A", strtotime($row['starttime'])) . ' - ' . date("h:i A", strtotime($row['endtime'])) ?></td>
                                             <td><?php echo $row['joiningdate'] ?></td>

                                         </tr>
                                     <?php
                                        endforeach;
                                        ?>

                                 </tbody>
                             </table>
                         </div>

                         <!-- Modal -->
                         <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog">
                                 <div class="modal-content">
                                     <div class="modal-header">
                                         <h5 class="modal-title" id="exampleModalLabel">Pending Inquiry</h5>
                                         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                                     </div>
                                     <form action="<?php echo base_url('/Admin/Admission/Save') ?>" method="post">
                                         <div class="modal-body">
                                             <input type="text" class="form-control" name="id" id="id" placeholder="" readonly>
                                            <br>
                                             <!-- <p><b>Full Name:</b> <span id="inquiryfirstname"></span></p> -->
                                             <div class="form-floating mb-2">
                                                <div class="row">
                                                <div class="col-md-6">
                                                     <div class="form-group">
                                                         <label for="">Total Fee</label>
                                                         <input type="text" class="form-control" name="totalfee" id="" placeholder="Enter Total Fee">
                                                     </div>

                                                 </div>
                                                 <div class="col-md-6">
                                                     <div class="form-group">
                                                         <label for="">Fee Paid</label>
                                                         <input type="text" class="form-control" name="paidfee" id="" placeholder="Enter Fee Paid">
                                                     </div>
                                                 </div>
                                                </div>
                                             </div>
                                             <div class="row">
                                             <div class="col-md-6">
                                                 <label>Mode of Payment:</label>
                                                 <select class="form-control custom-select" name="mode" id="mode">
                                                     <option value="">--Select Payment Mode--</option>
                                                     <option value="online">Online</option>
                                                     <option value="offline">Offline</option>
                                                 </select>
                                             </div>

                                             <div class="col-md-6">
                                                 <div class="form-group">
                                                     <label for="">Transaction Id <span>(if mode is online)</span> </label>
                                                     <input type="text" class="form-control" name="transactionid" id="" placeholder="Enter Transaction Id">
                                                 </div>
                                             </div>
                                             </div>
                                             
                                         </div>
                                         <div class="modal-footer">
                                             <button type="submit" class="btn btn-primary">Save changes</button>
                                         </div>
                                     </form>

                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>

     </div>

     <!-- JavaScript to ensure modal opens when clicking Pending -->
     <script>
         $(document).ready(function() {
             $(".openModalBtn").on("click", function() {
                 var inquiryId = $(this).data("id");
                 var inquiryfirstname = $(this).data("firstname");

                 console.log("Opening modal for Inquiry ID:", inquiryId);

                 // Update modal fields dynamically
                 $("#id").val(inquiryId);

                 $("#inquiryfirstname").text(inquiryfirstname);

                 // Open modal
                 $("#exampleModal").modal("show");
             });

             // Ensure close button works
             $(".btn-close").on("click", function() {
                 $("#exampleModal").modal("hide");
             });
         });
     </script>